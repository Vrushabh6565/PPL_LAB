import turtle

s = turtle.getscreen()
t = turtle.Turtle()
t.width(5)


class shape:
    def __init__(self, sides = 0, length = 0) :
        self.sides = sides
        self.length = length


class polygon(shape):
    def info(self):
        print("In geometry, a polygon can be defined as a flat or plane, two-dimensional  with straight sides.")
        
class square(polygon):
    def sides(self):
        print("sides =",4)
    def vertex(self):
        print("vertex = 4")
    def show(self):
        t.fd(self.length)
        t.rt(90)
        t.fd(self.length)
        t.rt(90)
        t.fd(self.length)
        t.rt(90)
        t.fd(self.length)
        t.rt(90)
    

class pentagon(polygon):
    def side(self):
        print("sides = ",self.sides)
    def vertex(self):
        print("vertex = ",self.sides)
    def show(self):
        for i in range(self.sides):
           t.forward(self.length) 
           t.right(72) 

class hexagon(polygon):
    def side(self):
        print("sides = ",self.sides)
    def vertex(self):
        print("vertex = ",self.sides)

    def show(self):
        for i in range(self.sides):
           t.forward(self.length) 
           t.right(60)

class octagon(polygon):
    def side(self):
        print("sides = ",self.sides)
    def vertex(self):
        print("vertex = ",self.sides)

    def show(self):
        for i in range(self.sides):
           t.forward(self.length) 
           t.right(45)

class triangle(polygon):
    def sides(self):
        print("sides = ",self.sides)
    def vertex(self):
        print("vertex = ",self.sides)

    def show(self):
        t.forward(self.length) 
        t.left(120)
        t.forward(self.length)
        t.left(120)
        t.forward(self.length)

class circle(shape):
    def show(self):
        t.circle(self.radius)

class circle():
    def show(self) :
        t.circle(40)



hex1 = hexagon( 6,100)
hex1.info()
hex1.side()
hex1.vertex()
hex1.show()
#p=circle()
#p.show()
#t.forward(105)
#t.color("yellow")
#t.forward(100)
#t.color("red")

#sq1 = square(4, 200)
#sq1.info()
#sq1.show()

#tr = triangle(3,50)
#tr.info()
#tr.show()

