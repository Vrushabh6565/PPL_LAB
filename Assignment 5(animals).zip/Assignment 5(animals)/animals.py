class Animals:
    def __init__(self,legs=4,eyes=2):
       self.legs=legs
       self.eyes=eyes

class domestic_animals(Animals):
    def place(self):
        print("Area habitated by Human Beings")

class wild_animals(Animals):
    def place(self):
        print("Jungle")
    def use(self):
        print("NO ANY DOMESTIC USE")

class herbivores(wild_animals):
    def food(self):
        print("Plants")

class carnivores(wild_animals):
    def food(self):
        print("meat, flesh")

class cow(domestic_animals):
    def speak(self):
        print("Moo")
    def color(self):
        print("White,Black")
    def use(self):
        print("give milk")
        
class buffalo(domestic_animals):
    def speak(self):
        print("Grunt")
    def color(self):
        print("Black")
    def use(self):
        print("give milk")


class dog(domestic_animals):
    def speak(self):
        print("Bark")
    def color(self):
        print("White, Black")

class goat(domestic_animals):
    def speak(self):
        print("Maa")
    def color(self):
        print("White, Black etc")
    def use(self):
        print("give milk")

class horse(domestic_animals):
    def speak(self):
        print("Whinny")
    def color(self):
        print("White, Black, Brown, etc")
    def use(self):
        print("Agriculture , Transport, riding etc")


class sheep(domestic_animals):
    def speak(self):
        print("Baa")
    def color(self):
        print("White")
    def use(self):
        print("Wool, milk etc")


class deer(herbivores):
    def speak(self):
        print("bellow")
    def color(self):
        print("reddish brown, grayish brown")

class elephant(herbivores):
    def speak(self):
        print("trumpet")
    def color(self):
        print("grayish black")

class giraffe(herbivores):
    def speak(self):
        print("bleat")
    def colour(self):
        print("dark brown, orange, stc")
        
class lion(carnivores):
    def speak(self):
        print("roar")
    def color(self):
        print("white, tawny yellow, ash brown, ochre, deep orange-brown")

class tiger(carnivores):
    def speak(self):
        print("roar")
    def color(self):
        print("dark brown, grey to black")

class wolf(carnivores):
    def speak(self):
        print("howl")
    def color(self):
        print("white, grizzled with browns, greys, black")

print("elephant")
animal1 = elephant()
animal1.speak()
animal1.place()
animal1.use()
animal1.color()
print(animal1.legs)
print(animal1.eyes)
animal1.eyes = 1
print(animal1.eyes)
print("horse")
animal2 = horse()
animal2.speak()
animal2.use()


